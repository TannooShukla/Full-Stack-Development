
 
  // your full script here
  const userTab = document.querySelector("[data-userWeather]");
const searchTab = document.querySelector("[data-searchWeather]");
const userContainer = document.querySelector(".weather-container");

const grantAccessContainer = document.querySelector(".grant-location-container");
const searchForm = document.querySelector("[data-searchForm]");
const loadingScreen = document.querySelector(".loading-container");
const userInfoContainer = document.querySelector(".user-info-container"); 
const grantAccessbtn = document.querySelector("[data-grantAccess]");
const searchInput=document.querySelector("[data-searchInput]");
const imgNotFound=document.querySelector(".notfound");

//initially vaiables need??
let currentTab=userTab;//currenttab=old tab
const API_KEY = "b2ba1216b7ec2252f9a23d6d775395b6";
currentTab.classList.add("current-tab");
getformSessionStorage();
//ek kaam pr pending hai??

function switchTab(clickedTab){
    if(clickedTab != currentTab){
      currentTab.classList.remove("current-tab"); 
      currentTab=clickedTab;
      currentTab.classList.add("current-tab");
      if(!searchForm.classList.contains("active")){
           userInfoContainer.classList.remove("active");
           grantAccessContainer.classList.remove("active");
           searchForm.classList.add("active");    
       }
       else{
        searchForm.classList.remove("active");
        userInfoContainer.classList.remove("active");
        getformSessionStorage(); 

       }
}
}
userTab.addEventListener("click", ()=>{
    switchTab(userTab);
});
searchTab.addEventListener("click", ()=>{
    switchTab(searchTab);
});

//  if (grantAccessbtn) grantAccessbtn.addEventListener("click", getLocation());

//   if (searchForm) {
//     searchForm.addEventListener("submit", (e) => {
//       e.preventDefault();
//       let cityName = searchInput.value.trim();
//       if(cityName === "") {
//         return alert("Please enter a city name");
//       } else {
//        fetchsearchWeatherInfo(cityName)
//       }
//     });
//   }

//check if coordinates are present in local storage
function getformSessionStorage(){
    const localcoordinates = sessionStorage.getItem("user-coordinates");
    if(!localcoordinates){
        //agr local storage me kuch nhi hai to
        //grant access
        grantAccessContainer.classList.add("active");
}
else{
    const coordinates = JSON.parse(localcoordinates);
    fetchUserWeatherInfo(coordinates);
}
}

 async function  fetchUserWeatherInfo(coordinates){
    const {lat,lon}=coordinates;
    //make grant access container inactive
    grantAccessContainer.classList.remove("active");
    //loading screen
    loadingScreen.classList.add("active");
    try{
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`);
        const data = await response.json();
        loadingScreen.classList.remove("active");
        imgNotFound.classList.remove("active");
        userInfoContainer.classList.add("active");
        renderUserInfo(data);
       
    }
    catch(error){
        loadingScreen.classList.remove("active");
        alert("An error occured while fetching the weather data.");
    }
}
function renderUserInfo(weatherInfo){
    //firstly we have to fetch the elements
    const cityname=document.querySelector("[data-cityName]");
    const countryicon=document.querySelector("[data-countryIcon]");
    const desc=document.querySelector("[data-weatherdesc]");
    const weatherIcon=document.querySelector("[data-weatherIcon]");
    const temp=document.querySelector("[data-temp]");
    const windSpeed=document.querySelector("[data-windSpeed]");
    const humidity=document.querySelector("[data-humidity]");
    const cloudiness=document.querySelector("[data-cloudiness]");
    //fetch the data from the api
    cityname.innerText=weatherInfo?.name;
    countryicon.src = `https://flagcdn.com/144x108/${weatherInfo?.sys?.country.toLowerCase()}.png`;
    desc.innerText=weatherInfo?.weather[0]?.description;
    weatherIcon.src= `http://openweathermap.org/img/wn/${weatherInfo?.weather[0]?.icon}@2x.png`;
   temp.innerText=`${weatherInfo?.main?.temp} °C`;
   windSpeed.innerText=`${weatherInfo?.wind?.speed}m/s`;
   humidity.innerText=`${weatherInfo?.main?.humidity}%`;
   cloudiness.innerText=`${weatherInfo?.clouds?.all}%`;

     
}
function getLocation(){
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showPosition);
    
}
else{
    alert("Geolocation is not supported by this browser.");
}
}
function showPosition(position){
  const userCoordinates={
      lat:position.coords.latitude,
      lon:position.coords.longitude
    
}
   sessionStorage.setItem("user-coordinates",JSON.stringify(userCoordinates));
   fetchUserWeatherInfo(userCoordinates);
}


grantAccessbtn.addEventListener("click", getLocation);
  

searchForm.addEventListener("submit",(e)=>{
    e.preventDefault();
    let cityName=searchInput.value;
    if(cityName===""){  
        return alert("Please enter a city name");
    }
    else{
        fetchsearchWeatherInfo(cityName);
    }
    
});

async function fetchsearchWeatherInfo(cityName){
    loadingScreen.classList.add("active");
    userInfoContainer.classList.remove("active");
    grantAccessContainer.classList.remove("active");
    try{
       const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}&units=metric`);
        const data = await response.json();
        console.log(data);
        loadingScreen.classList.remove("active");
        imgNotFound.classList.remove("active");
        userInfoContainer.classList.add("active");
        renderUserInfo(data);
    }
    catch(error){
       userInfoContainer.classList.remove("active");
       imgNotFound.classList.add("active");
      document.getElementById("myImage").src = "./assets/not-found.png";

    }
}






// document.addEventListener("DOMContentLoaded", () => {
//   const userTab = document.querySelector("[data-userWeather]");
//   const searchTab = document.querySelector("[data-searchWeather]");
//   const userContainer = document.querySelector(".weather-container");

//   const grantAccessContainer = document.querySelector(".grant-location-container");
//   const searchForm = document.querySelector("[data-searchForm]");
//   const loadingScreen = document.querySelector(".loading-container");
//   const userInfoContainer = document.querySelector(".user-info-container"); 
//   const searchInput = document.querySelector("[data-searchInput]");
//   const grantAccessbtn = document.querySelector("[data-grantAccess]");

//   let currentTab = userTab;
//   const API_KEY = "b2ba1216b7ec2252f9a23d6d775395b6";

//   currentTab.classList.add("current-tab");
//   getFormSessionStorage();

//   function switchTab(clickedTab){
//     if(clickedTab !== currentTab){
//       currentTab.classList.remove("current-tab"); 
//       currentTab = clickedTab;
//       currentTab.classList.add("current-tab");

//       if(!searchForm.classList.contains("active")){
//         userInfoContainer.classList.remove("active");
//         grantAccessContainer.classList.remove("active");
//         searchForm.classList.add("active");
//         searchForm.classList.remove("hidden");
//       }
//       else{
//         searchForm.classList.remove("active");
//         searchForm.classList.add("hidden");
//         userInfoContainer.classList.remove("active");
//         getFormSessionStorage(); 
//       }
//     }
//   }

//   userTab.addEventListener("click", () => switchTab(userTab));
//   searchTab.addEventListener("click", () => switchTab(searchTab));
//   if (grantAccessbtn) grantAccessbtn.addEventListener("click", getLocation);

//   if (searchForm) {
//     searchForm.addEventListener("submit", (e) => {
//       e.preventDefault();
//       let cityName = searchInput.value.trim();
//       if(cityName === "") {
//         return alert("Please enter a city name");
//       } else {
//         fetchSearchWeatherInfo(cityName);
//       }
//     });
//   }

//   function getFormSessionStorage(){
//     const localCoordinates = sessionStorage.getItem("user-coordinates");
//     if(!localCoordinates){
//       grantAccessContainer.classList.add("active");
//       grantAccessContainer.classList.remove("hidden");
//     } else {
//       const coordinates = JSON.parse(localCoordinates);
//       fetchUserWeatherInfo(coordinates);
//     }
//   }

//   async function fetchUserWeatherInfo(coordinates){
//     const { lat, lon } = coordinates;
//     grantAccessContainer.classList.remove("active");
//     grantAccessContainer.classList.add("hidden");
//     loadingScreen.classList.add("active");
//     loadingScreen.classList.remove("hidden");

//     try {
//       const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`);
//       const data = await response.json();
//       loadingScreen.classList.remove("active");
//       loadingScreen.classList.add("hidden");
//       userInfoContainer.classList.add("active");
//       renderUserInfo(data);
//     } catch (error) {
//       loadingScreen.classList.remove("active");
//       loadingScreen.classList.add("hidden");
//       alert("An error occurred while fetching weather.");
//     }
//   }

//   async function fetchSearchWeatherInfo(cityName){
//     loadingScreen.classList.add("active");
//     loadingScreen.classList.remove("hidden");
//     userInfoContainer.classList.remove("active");
//     grantAccessContainer.classList.remove("active");
//     grantAccessContainer.classList.add("hidden");

//     try {
//       const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}&units=metric`);
//       const data = await response.json();
//       if (data?.cod === "404") {
//         alert("City not found");
//         loadingScreen.classList.remove("active");
//         loadingScreen.classList.add("hidden");
//         return;
//       }
//       loadingScreen.classList.remove("active");
//       loadingScreen.classList.add("hidden");
//       userInfoContainer.classList.add("active");
//       renderUserInfo(data);
//     } catch (error) {
//       loadingScreen.classList.remove("active");
//       loadingScreen.classList.add("hidden");
//       alert("An error occurred while fetching weather.");
//     }
//   }

//   function renderUserInfo(weatherInfo){
//     document.querySelector("[data-cityName]").innerText = weatherInfo?.name;
//     const countryCode = weatherInfo?.sys?.country?.toLowerCase();
//     document.querySelector("[data-countryIcon]").src = `https://flagcdn.com/48x36/${countryCode}.png`;
//     document.querySelector("[data-weatherdesc]").innerText = weatherInfo?.weather?.[0]?.description;
//     document.querySelector("[data-weatherIcon]").src = `https://openweathermap.org/img/wn/${weatherInfo?.weather?.[0]?.icon}@2x.png`;
//     document.querySelector("[data-temp]").innerText = weatherInfo?.main?.temp;
//     document.querySelector("[data-windSpeed]").innerText = weatherInfo?.wind?.speed;
//     document.querySelector("[data-humidity]").innerText = weatherInfo?.main?.humidity;
//     document.querySelector("[data-cloudiness]").innerText = weatherInfo?.clouds?.all;
//   }

//   function getLocation(){
//     if(navigator.geolocation){
//       navigator.geolocation.getCurrentPosition(showPosition);
//     } else {
//       alert("Geolocation is not supported by your browser.");
//     }
//   }

//   function showPosition(position){
//     const userCoordinates = {
//       lat: position.coords.latitude,
//       lon: position.coords.longitude
//     };
//     sessionStorage.setItem("user-coordinates", JSON.stringify(userCoordinates));
//     fetchUserWeatherInfo(userCoordinates);
//   }
// });


