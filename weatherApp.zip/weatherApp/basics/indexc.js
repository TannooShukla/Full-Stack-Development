console.log("Hello World");
 const API_KEY = "b2ba1216b7ec2252f9a23d6d775395b6";
 async function renderWeatherData(data){
    let p=document.createElement("p");
   p.textContent=`${data?.main?.temp.toFixed(2)}°C`;
     document.body.appendChild(p);
   }
 
 async function WeatherData(){
   try{

      let city="xxa";
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
    const data = await response.json();

    console.log("data->",data);
    renderWeatherData(data);
    
   }
   catch(error){
    console.log("error:",error);
   }
    
}

async function getWeatherDataCustom(){
   try{
   let lat=17.6333;
   let lon=18.3333;
   let response=await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`);
   let data=await response.json();
   console.log(data);
   renderWeatherData(data);}
   catch(error){
    console.log("error found:",error);
   }
} 
    